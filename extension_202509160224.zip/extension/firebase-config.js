// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDsUUCleFadV60rV2TV07SvMi6YJ-XACWY",
  authDomain: "prezento-ai-coach.firebaseapp.com",
  projectId: "prezento-ai-coach",
  storageBucket: "prezento-ai-coach.firebasestorage.app",
  messagingSenderId: "819782463010",
  appId: "1:819782463010:web:6a48b5a5b04ede1ab2e47b",
  measurementId: "G-D7Q8FZ27GS"
};